import { createFileRoute, Link, Outlet } from '@tanstack/react-router'

export const Route = createFileRoute('/candidates')({
  component: RouteComponent,
})

function RouteComponent() {
  return <div>
    <div>
      <div className="px-2 font-bold">
        <Link to = '/candidates'>Reviewing</Link>
      </div>
      <div className="px-2 font-bold">
        <Link to = '/candidates' >Pending</Link>
      </div>
    </div>
    <Outlet/>
  </div>
}
