import { getCandidates } from '@/api/candidate'
import Candidate from '@/components/candidate'
import { createFileRoute, Link } from '@tanstack/react-router'
import type { CandidateType } from '@/types/candidate'



type searchParams = {
  status?: string
}
export const Route = createFileRoute('/candidates/')({
  component: RouteComponent,
  validateSearch: (search: Record<string, string | undefined>): searchParams  => ({
    status: search.status,
  }),
  loaderDeps: ({search}) => ({
    status: search.status,
  }),

  loader:  ({deps: {status}}) => {
    return new Promise<Array<CandidateType>>((resolve) => {
      setTimeout(() => {
        resolve(getCandidates(status))
      }, 3000)
    })

  }
})






function RouteComponent() {
  const data = Route.useLoaderData();

  

  return <div>
    <h1>Candidates</h1>
    
    {data.status && <h2>Status: {data.status}</h2>}
    <section className="flex flex-row gap-4 m-4">
        {data.map((candidate, index) => (
          <Candidate key={index} data={candidate} />
        ))}
      </section>
  </div>
}
